

let saved_username="Anshul11";
let saved_password="Dhakate@1"

let username="Anshul11";
let password="Dhakate@1"

if(saved_username==username){
  console.log("you can login")
}
else if(saved_password==password){
  console.log("you cannot login")
}
