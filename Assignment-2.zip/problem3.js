
let a=20;
let b=10;
if(a>b){
  console.log("a is greater than b")
}
else if(a==b){
  console.log("both are equal");
}


let a=20;
let b=20;
if(a>b){
  console.log("a is greater than b")
}
else if(a==b){
  console.log("both are equal");
}
