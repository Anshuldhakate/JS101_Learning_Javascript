
let a=9;

if(a%3== 0){
  console.log("multiple of 3");
}