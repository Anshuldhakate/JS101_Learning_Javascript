let name = "Anshul";
let age = 27;

console.log(name, age);

console.log(typeof (name));
console.log(typeof (age));
