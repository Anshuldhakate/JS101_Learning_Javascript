let name="Anshul";
console.log(name);

name="Raju";
console.log(name);

name="Tara";
console.log(name);