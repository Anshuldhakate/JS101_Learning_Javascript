let name = "Anshul Dhakate";
let school = "Bharat Vidyalaya Nagpur";
let grade = "A+";
let section = "A";
let rollno = 07;


console.log("         ***Report Card***      ")
console.log("*Name       -", name);
console.log("*School Name-",school);
console.log("*Grade      -",grade);
console.log("*Section    -",section);
console.log("*Roll No.   -",rollno);
console.log("*Scores     -Maths   - 80/100");
console.log("            -English - 75/100");
console.log("            -Science - 85/100");