let a="Masai School";
let b="A Transformation in Education";

console.log(a);
console.log(b);

console.log(a,b);
